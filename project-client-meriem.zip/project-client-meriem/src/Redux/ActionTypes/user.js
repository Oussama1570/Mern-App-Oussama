export const SUCC_USER = "SUCC_USER";
export const REG_USER = "REG_USER";
export const LOAD_USER = "LOAD_USER";
export const FAIL_USER = "FAIL_USER";
export const LOGOUT_USER = "LOGOUT_USER";
export const CURRENT_USER = "CURRENT_USER";
