export const SUCC_PRODUCT = "SUCC_PRODUCT";
export const LOAD_PRODUCT = "LOAD_PRODUCT";
export const FAIL_PRODUCT = "FAIL_PRODUCT";
export const GET_PRODUCT = "GET_PRODUCT";
