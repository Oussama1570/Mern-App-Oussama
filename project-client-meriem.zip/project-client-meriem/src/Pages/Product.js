import React from "react";
import ProductList from "../Components/ProductList";

const Product = () => {
	return (
		<div>
			<ProductList />
		</div>
	);
};

export default Product;
